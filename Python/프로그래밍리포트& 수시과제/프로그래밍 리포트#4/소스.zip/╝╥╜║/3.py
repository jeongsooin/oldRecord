# tabto4space.py
import re
import sys

# usage 함수 정의
# 안내문을 출력하는 함수
def usage():
    print("Usage: python %sfilename"%sys.argv[0])

# 파일 오픈을 try한다.
# except의 경우 usage 함수 호출하고 프로그램 빠져나감
# 에러로 인해 프로그램이 종료됨을 의미
try:
    f= open(sys.argv[1])
except:
    usage();sys.exit(2)

# 파일을 읽어와 msg 변수에 저장
# 탭 패턴을 만들고
# sub 함수를 이용하여 패턴과 매칭되는 부분을 공백 4개로 바꿈
msg = f.read()
f.close
p = re.compiler(r'\t')
changed = p.sub(""*4,msg)

# 쓰기 모드로 파일을 열어 바꾼 것을 저장하고
# 파일 닫기 
f = open(sys.argv[1],'w')
f.write(changed)
f.close()
