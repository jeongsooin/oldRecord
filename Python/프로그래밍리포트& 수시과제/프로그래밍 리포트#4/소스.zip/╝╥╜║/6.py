# 결과를 저장할 변수를 만든다.
result = 0
# 1 부터 1000미만의 자연수를 구하기 위해 range 함수 이용
# %연산자로 3 또는 5의 배수를 구한다.
# 조건에 해당하는 자연수들을 result에 더한다.
for i in range(1,1000):
    if i % 3 == 0 or i% 5 == 0:
        result +=i
#결과를 출력한다.
print(result)
