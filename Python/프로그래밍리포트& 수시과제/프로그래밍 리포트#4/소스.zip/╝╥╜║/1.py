
# 구구단 함수를 루프를 이용하여 정의
# 리스트를  만들고 리스트에 n*i 한 값을
# 루프를 돌며 리스트에 계속 추가
def GuGu(n):
    result = []
    i = 1
    while i <10:
        result.append(n*i)
        i = i+1
    return result

# 정의한 함수를 값을 넣어 출력
print(GuGu(2))
