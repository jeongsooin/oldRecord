def getPage(m,n):
    # 인자로 들어온 총 건수 m을 한 페이지에 보여줄 건수 n으로 나눔
    # 나머지가 0보다 크면 보여줄 페이지는 +1
    # 계산한 page를 호출한 곳으로 돌려준다. 
    page,remainder = divmod(m,n)
    if remainder > 0:
        page += 1
    return page
