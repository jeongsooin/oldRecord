import os

def search(dirname):
    # 디렉토리 안에 있는 파일들을 순차적으로 검색한다.
    # 디렉토리 안에 파일이 있을때 doFileWork 함수를 호출하고
    # 또 다른 디렉토리가 있으면 search 함수를 다시 호출 한다.
    # 재귀 호출 이용
    flist = os.listdir(dirname)
    for f in flist:
        next = os.path.join(dirname,f)
        if os.path.isdir(next):
            search(next)
        else:
            doFileWork(next)

            
def doFileWork(filename):
    # .py 확장자를 가진 파일인지 확인하고, 아니면 그냥 리턴
    # 파일을 열어 내용을 읽어온다.
    # 파일안에 있는 ABC를 DEF로 바꾸어 변수에 저장하고
    # 파일을 쓰기모드로 열어 저장한다. 
    ext = os.path.splitext(filename)[-1]
    if ext !='.py':
        return
    f = open(filename)
    before = f.read()
    f.close()
    after = before.replace("ABC","DEF")
    f = open(filename,"w")
    f.write(after)
    f.close()

# D 드라이브 안의 파일을 검색한다. 
search("d:/")
