import sys
import time

# usage 함수를 정의
# 안내문을 출력한다
def usage():
    print("""
Usage
====
python %s -v : View memo
python %s -a : Add memo
"""% (sys.argv[0], sys.argv[0]))

# 올바른 인자가 아닐 때 다시 usage 함수를 호출
if not sys.argv[1:] or sys.argv[1] not in ['-v','-a']:
        usage()
# 만약 -v가 들어오면 파일을 읽기 모드로 열도록 try
# 텍스트 파일이 없을 경우 프로그램이 죽지 않도록 except처리
elif sys.argv[1] == '-v':
    try:
        print(open("memo.txt").read())
    except IOError:
        print("memo does not exist!")

# 만약 -a가 들어오면 메모에 저장할 단어를 입력받고
# 파일을 이어쓰기 모드로 열어서 시간+입력 단어+줄바꿈 문자와 저장
# 파일을 닫고, 저장됐음을 알리는 문구 출력
elif sys.argv[1] == '-a':
    word = input("Enter memo:")
    f = open("memo.txt",'a')
    f.write(time.ctime() + ':' + word + '\n')
    f.close()
    print("Added")
